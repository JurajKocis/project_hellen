package sk.tuke.oop.game.actors;

public interface Observer {
    void giveNotice();
}
