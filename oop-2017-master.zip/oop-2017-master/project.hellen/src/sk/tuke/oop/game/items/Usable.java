package sk.tuke.oop.game.items;

import sk.tuke.oop.framework.Actor;

public interface Usable {
    void useBy(Actor actor);
}
