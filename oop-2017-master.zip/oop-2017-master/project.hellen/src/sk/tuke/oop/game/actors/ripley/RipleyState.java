package sk.tuke.oop.game.actors.ripley;

public interface RipleyState {
     void act(int y, int x);
}