package sk.tuke.oop.game.actors;

import sk.tuke.oop.framework.Actor;

public interface Movable extends Actor{
    
    default void collidedWithWall(){
    }
}