package sk.tuke.oop.game.actors.enemies;

public interface Enemy {
}
