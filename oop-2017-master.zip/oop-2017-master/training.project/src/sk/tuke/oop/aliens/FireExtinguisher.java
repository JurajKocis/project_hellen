package sk.tuke.oop.aliens;

public class FireExtinguisher extends AbstractTool {
    public FireExtinguisher(){
        super(1);
    }
}
