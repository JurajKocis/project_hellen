package sk.tuke.oop.aliens;

public interface EnergyConsumer {
        void setElectricityFlow(boolean arg);
}
