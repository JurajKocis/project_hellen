package sk.tuke.oop.aliens;

public interface Repairable {

    void repairWith(AbstractTool abstractTool);
}
